//
//  abc.swift
//  SwiftDemo
//
//  Created by Infusion Infotech on 8/31/16.
//  Copyright © 2016 Dipen Lad. All rights reserved.
//

import UIKit

class abc: NSObject
{
    weak var strName : NSString!

}
